DEVICEGROUP.type = "generator_gas_steam"

--[[
	You can also use skin = number here to define a skin to make the Module spawn with
	You can also use material = "path/to/material" to set a material to make it spawn with
]]

DEVICEGROUP.devices = {
    add_one = {
        Name = "CE Small Water Heater",
        model = "models/ce_ls3additional/water_heater/water_heater.mdl",
        skin = 0
    },
}

