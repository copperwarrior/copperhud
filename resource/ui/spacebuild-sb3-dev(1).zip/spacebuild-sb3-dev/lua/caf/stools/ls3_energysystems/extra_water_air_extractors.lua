DEVICEGROUP.type = "generator_gas_o2h_water"

--[[
	You can also use skin = number here to define a skin to make the Module spawn with
	You can also use material = "path/to/material" to set a material to make it spawn with
]]

DEVICEGROUP.devices = {
    add_one = {
        Name = "CE Medium Water Splitter",
        model = "models/ce_ls3additional/water_air_extractor/water_air_extractor.mdl",
        skin = 0
    },
}

