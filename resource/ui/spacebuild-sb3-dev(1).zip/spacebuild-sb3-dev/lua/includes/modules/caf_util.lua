--=============================================================================--
-- 			Addon: CAF
-- 			Author: SnakeSVx
--			Version: 0.1
--
--  A really simple module to allow the creation of Java like ArrayLists
--
--=============================================================================--

local IsValid = IsValid
local util = util
local string = string
local tostring = tostring
local Msg = Msg

module( "caf_util" )

local list = {}
list.__index = list



