ENT.Type = "anim"
ENT.Base = "base_sb_environment"
ENT.PrintName = "Base Spacebuild Star 1 (Compatiblity map versions < 3)"
