ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "One Way Valve"
ENT.Author = "SnakeSVx"
ENT.Purpose = "Resource Node -> Resource Node Connection Valve"
ENT.Instructions = ""
ENT.IsValve = true
ENT.IsEntityValve = false
ENT.IsNodeValve = false
ENT.IsOneWayValve = true

ENT.Spawnable = false
ENT.AdminSpawnable = false
