ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Liquid Nitrogen Recycler"
ENT.AutomaticFrameAdvance = true

list.Set("LSEntOverlayText", "generator_recycler_liq_nitrogen", { HasOOO = true, resnames = { "energy", "hot liquid nitrogen", "liquid nitrogen" }, genresnames = { "liquid nitrogen" } })
