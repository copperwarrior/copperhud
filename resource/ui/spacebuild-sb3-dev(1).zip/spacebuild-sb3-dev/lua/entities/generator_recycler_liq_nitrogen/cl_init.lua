include('shared.lua')

language.Add("generator_recycler_liq_nitrogen", "Liquid Nitrogen Recycler")
