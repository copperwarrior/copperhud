include('shared.lua')

language.Add("storage_liquid_water", "Water Storage")
