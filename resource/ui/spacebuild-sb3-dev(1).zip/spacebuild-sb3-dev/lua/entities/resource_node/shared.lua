-- Much love to the WireMod team for their superb LUA coding
ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Resource Distribution Entity"
ENT.Author = "Thresher and TAD2020"
ENT.Purpose = "Base for all RD Sents"
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false

ENT.IsNode = true
