include('shared.lua')

language.Add("generator_energy_hydro", "Hydro Energy Generator")
