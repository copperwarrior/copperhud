include('shared.lua')

language.Add("generator_gas_o2h_water", "Oxygen/Hydrogen Extractor")
