ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Water Air Extractor"

list.Set("LSEntOverlayText", "generator_gas_o2h_water", { HasOOO = true, resnames = { "energy", "water" }, genresnames = { "hydrogen", "oxygen" } })
