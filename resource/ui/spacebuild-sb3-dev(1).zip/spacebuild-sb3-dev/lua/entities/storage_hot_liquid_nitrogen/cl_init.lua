include('shared.lua')

language.Add("storage_hot_liquid_nitrogen", "Hot Liquid Nitrogen Storage")
