ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Hot Liquid Nitrogen Tank"

list.Set("LSEntOverlayText", "storage_hot_liquid_nitrogen", { num = -1 })
