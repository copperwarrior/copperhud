include('shared.lua')

language.Add("generator_energy_wind", "Wind Energy Generator")
