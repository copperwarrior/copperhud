ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Wind Generator"
ENT.AutomaticFrameAdvance = true

list.Set("LSEntOverlayText", "generator_energy_wind", { HasOOO = true, genresnames = { "energy" } })
