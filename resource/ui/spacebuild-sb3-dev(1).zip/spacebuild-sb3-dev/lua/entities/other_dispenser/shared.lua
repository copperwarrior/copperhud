ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Suit Dispenser"

list.Set("LSEntOverlayText", "other_dispenser", { resnames = { "oxygen", "energy", "water", "nitrogen" } })
