include('shared.lua')

language.Add("other_dispenser", "Dispenser")
