ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Liquid Nitrogen Generator"
ENT.AutomaticFrameAdvance = true

list.Set("LSEntOverlayText", "generator_liquid_nitrogen", { HasOOO = true, resnames = { "energy", "nitrogen" }, genresnames = { "liquid nitrogen" } })
