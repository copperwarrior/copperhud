include('shared.lua')

language.Add("generator_liquid_nitrogen", "Liquid Nitrogen Generator")
