-- Much love to the WireMod team for their superb LUA coding
-- Based on the RD2 base_rd_entity made by Thresher and TAD2020

ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Spacebuild Dev Tree"
ENT.Author = "SnakeSVx"
ENT.Purpose = "Spacebuild Dev Tree"
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false
