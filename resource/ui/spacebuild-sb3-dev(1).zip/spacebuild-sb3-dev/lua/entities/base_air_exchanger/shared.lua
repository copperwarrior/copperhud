ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Air Exchanger"

list.Set("LSEntOverlayText", "base_air_exchanger", { HasOOO = true, num = -1 })
