ENT.Type = "anim"
ENT.Base = "base_sb_environment"
ENT.PrintName = "Gravity Regulator"

list.Set("LSEntOverlayText", "base_gravity_control", { HasOOO = true, resnames = { "energy" } })
