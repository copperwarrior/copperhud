ENT.Type = "anim"
ENT.Base = "base_sb_environment"
ENT.PrintName = "Climate Regulator"

list.Set("LSEntOverlayText", "base_climate_control", { HasOOO = true, resnames = { "oxygen", "energy", "water", "nitrogen" } })
