include('shared.lua')

language.Add("generator_liquid_hvywater", "Heavy Water Generator")
