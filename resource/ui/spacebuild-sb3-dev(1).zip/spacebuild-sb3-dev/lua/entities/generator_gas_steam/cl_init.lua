include('shared.lua')

language.Add("generator_gas_steam", "Water Heater")
