ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Water Heater"

list.Set("LSEntOverlayText", "generator_gas_steam", { HasOOO = true, resnames = { "energy", "water" }, genresnames = { "steam" } })
