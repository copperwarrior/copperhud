-- Much love to the WireMod team for their superb LUA coding
-- Based on the RD2 base_rd_entity made by Thresher and TAD2020

ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "RD Pump"
ENT.Author = "SnakeSVx"
ENT.Purpose = "Base RD Pump"
ENT.Instructions = ""

ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.IsPump = true

list.Set("LSEntOverlayText", "rd_pump", { HasOOO = true })
