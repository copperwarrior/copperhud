ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Water Pump"
ENT.AutomaticFrameAdvance = true

list.Set("LSEntOverlayText", "generator_liquid_water", { HasOOO = true, resnames = { "energy" }, genresnames = { "water" } })
