include('shared.lua')

language.Add("generator_liquid_water", "Water Pump")
