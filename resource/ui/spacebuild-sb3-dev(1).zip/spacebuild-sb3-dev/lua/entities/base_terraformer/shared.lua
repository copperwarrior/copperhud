ENT.Type = "anim"
ENT.Base = "base_rd3_entity"

ENT.PrintName = "Planet Terraformer (WIP)"
ENT.Author = "PortalCake"
ENT.Purpose = "Terraforms Planets"
ENT.Instructions = ""

list.Set("LSEntOverlayText", "base_terraformer", { HasOOO = true, resnames = { "energy", "oxygen", "carbon dioxide", "hydrogen", "nitrogen", "water" } })
