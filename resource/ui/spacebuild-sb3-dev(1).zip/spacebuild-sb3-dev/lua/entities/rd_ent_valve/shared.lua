ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Entity Valve"
ENT.Author = "SnakeSVx"
ENT.Purpose = "Entity <-> Resource Node Connection Valve"
ENT.Instructions = ""
ENT.IsValve = true
ENT.IsEntityValve = true
ENT.IsNodeValve = false
ENT.IsOneWayValve = false

ENT.Spawnable = false
ENT.AdminSpawnable = false
