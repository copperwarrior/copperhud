ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Energy Cell"

list.Set("LSEntOverlayText", "storage_energy", { num = -1 })
