include('shared.lua')

language.Add("storage_energy", "Battery")
