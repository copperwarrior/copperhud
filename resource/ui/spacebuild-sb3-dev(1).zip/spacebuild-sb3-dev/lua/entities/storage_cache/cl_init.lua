include('shared.lua')

language.Add("storage_cache", "Storage Cache")
