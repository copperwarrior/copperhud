ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Storage Cache"

list.Set("LSEntOverlayText", "storage_cache", { num = -1 })
