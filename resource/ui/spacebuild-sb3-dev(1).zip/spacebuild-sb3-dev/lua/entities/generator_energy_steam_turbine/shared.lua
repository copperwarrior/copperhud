ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Steam Turbine"

list.Set("LSEntOverlayText", "generator_energy_steam_turbine", { HasOOO = true, resnames = { "steam" }, genresnames = { "energy", "water" } })
