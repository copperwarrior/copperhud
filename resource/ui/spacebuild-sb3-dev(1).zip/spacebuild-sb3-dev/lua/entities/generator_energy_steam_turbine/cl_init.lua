include('shared.lua')

language.Add("generator_energy_steam_turbine", "Steam Turbine")
