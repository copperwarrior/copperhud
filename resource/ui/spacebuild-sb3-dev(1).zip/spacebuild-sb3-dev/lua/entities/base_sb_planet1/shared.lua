ENT.Type = "anim"
ENT.Base = "base_sb_environment"
ENT.PrintName = "Base Spacebuild Planet 1 (Compatiblity map versions < 2.5)"
