include('shared.lua')

language.Add("storage_gas", "Gas Storage")
