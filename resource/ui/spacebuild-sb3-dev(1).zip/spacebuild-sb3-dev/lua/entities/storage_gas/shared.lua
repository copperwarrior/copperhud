ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Gas Tank"

list.Set("LSEntOverlayText", "storage_gas", { num = -1 })
