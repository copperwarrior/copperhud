include('shared.lua')

language.Add("generator_gas", "Gas Generator")
