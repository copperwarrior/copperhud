ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Gas Compressor"

list.Set("LSEntOverlayText", "generator_gas", { HasOOO = true, resnames = { "energy" } })
