include('shared.lua')
language.Add("other_spotlight", "Life Support Spotlight")
