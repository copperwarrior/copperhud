include('shared.lua')

language.Add("generator_liquid_water2", "O2H => Water generator")
