ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Hydrogen Fuel Cell"

list.Set("LSEntOverlayText", "generator_liquid_water2", { HasOOO = true, resnames = { "hydrogen", "oxygen" }, genresnames = { "water" } })
