include('shared.lua')

language.Add("generator_n_ramscoop", "Deep Space Ram Scoop")
