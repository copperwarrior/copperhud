ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Steam Tank"

list.Set("LSEntOverlayText", "storage_gas_steam", { num = -1 })
