ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Fusion Reactor"

list.Set("LSEntOverlayText", "generator_energy_fusion", { HasOOO = true, num = 2, resnames = { "water", "heavy water" }, genresnames = { "energy", "steam", "water" } })
