include('shared.lua')

language.Add("generator_energy_fusion", "Fusion Generator")
