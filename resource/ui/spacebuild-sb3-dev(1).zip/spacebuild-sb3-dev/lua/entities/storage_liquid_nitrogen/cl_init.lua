include('shared.lua')

language.Add("storage_liquid_nitrogen", "Liquid Nitrogen Storage")
