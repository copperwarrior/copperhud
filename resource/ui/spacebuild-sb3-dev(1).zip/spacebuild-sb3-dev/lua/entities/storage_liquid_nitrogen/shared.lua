ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Liquid Nitrogen Tank"

list.Set("LSEntOverlayText", "storage_liquid_nitrogen", { num = -1 })
