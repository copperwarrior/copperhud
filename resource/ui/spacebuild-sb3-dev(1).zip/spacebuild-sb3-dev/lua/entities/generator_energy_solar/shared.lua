ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Solar Panel"

list.Set("LSEntOverlayText", "generator_energy_solar", { HasOOO = true, genresnames = { "energy" } })
