ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Life Support Screen"
ENT.IsScreen = true
