ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Atmospheric Probe"

list.Set("LSEntOverlayText", "other_probe", { HasOOO = false, resnames = { "energy" }})
