ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Nitrogen Recycler"
ENT.AutomaticFrameAdvance = true

list.Set("LSEntOverlayText", "generator_recycler_nitrogen", { HasOOO = true, resnames = { "energy", "liquid nitrogen" }, genresnames = { "nitrogen" } })
