include('shared.lua')

language.Add("generator_recycler_nitrogen", "Nitrogen Generator Recycler")
