ENT.Type = "anim"
ENT.Base = "base_gmodentity"

ENT.PrintName = "Resource Node (2-way) Valve"
ENT.Author = "SnakeSVx"
ENT.Purpose = "Resource Node <-> Resource Node Connection Valve"
ENT.Instructions = ""
ENT.IsValve = true
ENT.IsEntityValve = false
ENT.IsNodeValve = true
ENT.IsOneWayValve = false

ENT.Spawnable = false
ENT.AdminSpawnable = false
