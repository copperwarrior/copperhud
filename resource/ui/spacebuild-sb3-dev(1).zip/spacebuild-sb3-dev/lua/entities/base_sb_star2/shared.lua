ENT.Type = "anim"
ENT.Base = "base_sb_environment"
ENT.PrintName = "Base Spacebuild Star"
