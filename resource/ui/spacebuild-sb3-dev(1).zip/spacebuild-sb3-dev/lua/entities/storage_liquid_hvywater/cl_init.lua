include('shared.lua')

language.Add("storage_liquid_hvywater", "Heavy Water Storage")
