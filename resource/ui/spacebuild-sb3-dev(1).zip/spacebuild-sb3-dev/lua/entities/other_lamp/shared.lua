ENT.Type = "anim"
ENT.Base = "base_rd3_entity"
ENT.PrintName = "Life Support Lamp"

list.Set("LSEntOverlayText", "other_lamp", { HasOOO = true, resnames = { "energy" } })
