include('shared.lua')
language.Add("other_lamp", "Life Support Lamp")
