# 19.02.2015
 * **Bugfix:** Fixed Resource Nodes. No really, I did (this time).
 * **Bugfix:** Fixed many typos.
 * **Tweak:** Removed a shitload of debugging statements.